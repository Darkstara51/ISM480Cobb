from classes import *

my_ism_professor = ISMProfessor("Neil deGrasse Tyson", 65, "ISM480")
my_ism_professor.greet_students()